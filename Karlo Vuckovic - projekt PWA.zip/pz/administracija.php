<?php
    session_start();
    include 'update.php';
    include 'connect.php';
    define('upath','img/');
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css"/>
    <title>Administracija</title>

</head>
<body>
<header>
<?php 
$date =date("D, M d, Y");
?>
        <div class="banner">
            <p class="logo">Newsweek</p>
            <aside><?php echo $date?></aside>
        </div>
        <nav>
            <ul class="nav_links">
                <li><a href="index.php">Home</a></li>
                <li><a href="sport.php">Sport</a></li>
                <li><a href="glazba.php">Glazba</a></li>
                <li><a href="unos.html">Unos clanka</a></li>
                <li><a href="registracija.php" class="active">Administracija</a></li>
              </ul>
        </nav>
    </header>
     
<section class="formareg">
    <form  method="POST" id="form" enctype="multipart/form-data">
        
        <label for="username">Username</label><br>
        <input type="text" name="username" id="username">
        <span id="porukaUsername" class="error"></span><br>

        <label for="password">Password</label><br>
        <input type="password" name="password" id="password"> 
        <span id="poljePassword" class="error"></span><br>

        <button type="submit" name="submit">Log in</button><br><br>
        

        <label for="redirect"><a href="registracija.php">Nemate racun? Registrirajte se!</a></label><br><br>
    </form>
</section>
<?php
if(isset($_POST['password']) && isset($_POST['username'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

//Check input values
/*echo "Username: " . htmlspecialchars($username) . "<br>";
echo "Password: " . htmlspecialchars($password) . "<br>";*/



    $query = "SELECT korisnicko_ime,lozinka, razina FROM korisnici WHERE korisnicko_ime=?";
    $stmt = mysqli_stmt_init($dbc);

    if(mysqli_stmt_prepare($stmt, $query)){
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt,$user,$pass,$razina);
        mysqli_stmt_fetch($stmt);
        

//Check if any rows were returned
/*echo "Rows returned: " . mysqli_stmt_num_rows($stmt) . "<br>";
echo "Username from DB: " . htmlspecialchars($user) . "<br>";
echo "Hashed password from DB: " . htmlspecialchars($pass) . "<br>";*/



        if (password_verify($_POST['password'], $pass) && mysqli_stmt_num_rows($stmt)>0) {
                $prijava = true;
                if($razina == 1){
                    $admin= true;
                    echo'Razina korisnika je administrator';
                }else{
                    $admin=false;
                }
                $_SESSION['username'] = $user;
                $_SESSION['razina'] = $razina;
        }else{
            echo"Login nije uspio";
            $prijava = false;
        }
    }
}
?>


<?php
if(isset($prijava)){
    if(($prijava==true && $admin == true) || (isset($_SESSION['username']) && $_SESSION['razina']==1)){
        echo '<form method = "POST"><input type="submit" name="logout" value="Odjava"></form>';
        $selectedSport='';
        $selectedGalzba='';
        
        
        $query="SELECT * FROM clanci";
            $result=mysqli_query($dbc,$query);
                $br=0;
                echo'<section class="adminsection">';
                echo'<article class="admin">';
                while($row=mysqli_fetch_array($result)){
                
                echo "<form enctype='multipart/form-data' class='adminforma' action='' method='POST'>";

           
                echo "<input type='hidden' name='id' value='".$row['id']."'>";
    
                echo "<label for='naslov'>Naslov vijesti</label><br>";
                echo "<input type='text' name='naslov' id='naslov' value='".$row['naslov']."'><br>";
    
                echo "<label for='about'>Kratki sadržaj vijesti</label><br>";
                echo "<textarea name='ks' id='ks' cols='30' rows='10'>".$row['kratki_sadrzaj']."</textarea><br>";
    
                echo "<label for='sadrzaj'>Sadržaj vijesti</label><br>";
                echo "<textarea name='sadrzaj' id='sadrzaj' cols='30' rows='10'>".$row['sadrzaj']."</textarea><br>";
    
                echo "<label for='slika'>Slika: </label><br>";
               echo "<div class='form-item'>";
                    echo "<input type='file' id='slika' name='slika' accept='image/jpg,image/gif,image/png'/> ";
                    echo "<img src='img/".$row['slika']."' width='100px' height='100px'>";
               echo "</div>";
                
    
                if($row['kategorija']=='Sport')
                {
                    $selectedSport="selected";
                }
                else
                {
                    $selectedSport="";
                }
                if($row['kategorija']=='Glazba')
                {
                    $selectedGlazba="selected";
                }
                
    
                echo "<select name='kategorija' id='kategorija' value='".$row['kategorija']."'><br>";
                    echo "<option value='sport'".$selectedSport.">Sport</option>";
                    echo "<option value='Glazba' ".$selectedGlazba.">Glazba</option>";

                echo "</select><br>";
    
                if($row['arhiva']==0)
                {
                    echo "<label><input id='' type='checkbox' id='arhiva' name='arhiva' >Arhiviraj?</label><br><br>";
                }
                else
                {
                    echo "<label><input type='checkbox' name='arhiva' id='arhiva'  checked>Arhiviraj?</label><br><br>";
                }
    
                echo "<input type='submit'  name='update' value='Ažuriraj'>";
                echo "<input type='submit'  name='delete' value='Izbriši'>";
                echo "<input type='reset'  name='reset' value='Resetiraj'>";
            echo "</form>";
            echo"<hr>";
        }

    }elseif($prijava == true && $admin == false || (isset($_SESSION['username']) && $_SESSION['razina']==0))
    {
        echo "<p>Bok ".$_SESSION['username']."! Uspješno ste prijavljeni, ali niste administrator.</p><br>";
        echo '<form method = "POST"><input type="submit" name="logout" value="Odjava"></form><br>';
    }
 
    else if($prijava == false){
    ?>
        <script>
          function validateForm(event) {
              var slanje = true;
  
              var poljeUsername = document.getElementById("username");
              var username = poljeUsername.value;
              var porukaUsername = document.getElementById("porukaUsername");
              if (username.length == 0) {
                  porukaUsername.innerText = "Unesite username!";
                  slanje = false;
                  poljeUsername.style.border= "1px solid red";
              } else {
                  porukaUsername.innerText = "";
                  poljeUsername.style.border= "1px solid green";
              }
  
             
              var poljePassword = document.getElementById("password");
              var password = poljePassword.value;
              var porukaPassword = document.getElementById("poljePassword");
              if (kratki.length > 100 || kratki.length < 10 ) {
                  porukaPassword.innerText = "Kratki sadrzaj treba imati od 10 do 100 znakova!";
                  slanje = false;
                  poljePassword.style.border= "1px solid red";
              } else {
                  porukaPassword.innerText = "";
                  poljePassword.style.border= "1px solid green";
              }
             
              if (!slanje) {
                  event.preventDefault();
              } 
          }
  
          window.onload = function() {
              document.getElementById("form").addEventListener("submit", validateForm);
          }
      </script>
  
          <?php
}

}
?>
<?php
        if(isset($_POST['logout']))
        {
            session_unset();
            session_destroy();
            header("Location: index.php");
        }

        if(isset($_POST['delete'])){
            $id=$_POST['id'];
            $query = "DELETE FROM clanci WHERE id=$id ";
            $result = mysqli_query($dbc, $query);
           }
        ?>

<footer>
        <p>© NEWSWEEK 2024.</p>
    </footer>
</body>