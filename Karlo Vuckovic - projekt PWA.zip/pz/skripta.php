<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pregled clanka</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    
</head>
<body>
<header>
<?php 
$date =date("D, M d, Y");
?>
        <div class="banner">
            <p class="logo">Newsweek</p>
            <aside><?php echo $date?></aside>
        </div>
        <nav>
            <ul class="nav_links">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="sport.php">Sport</a></li>
                <li><a href="glazba.php">Glazba</a></li>
                <li><a href="unos.html">Unos clanka</a></li>
                <li><a href="administracija.php">Administracija</a></li>
              </ul>
        </nav>
    </header>
    <?php
    include 'unos.php';

    if(isset($_POST['naslov']) && isset($_POST['ks']) 
        && isset($_POST['sadrzaj']) && isset($_POST['slika']) 
    && isset($_POST['kategorija'])){
        $naslov=$_POST['naslov'];
        $ks=$_POST['ks'];
        $sadrzaj=$_POST['sadrzaj'];
        $slika = $_FILES['slika']['name'];
        $kategorija=$_POST['kategorija'];
    }
    ?>
    <h1><?php echo $kategorija ?></h1>
    <h1><?php echo $naslov ?></h1>
    <?php echo"<img src='img/$slika'class='slika'>";?>
    <p><?php echo $ks?></p>
    <p><?php echo $sadrzaj?></p>

    <footer>
        <p>© NEWSWEEK 2024.</p>
    </footer>
</body>
</html>