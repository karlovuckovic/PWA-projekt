<!DOCTYPE html>
<html lang="hr">
<?php
session_start();
include 'connect.php';
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Karlo Vuckovic">
    <link rel="stylesheet" href="css/style.css">
    <title>Newsweek</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
<header>
<?php 
$date =date("D, M d, Y");
?>
        <div class="banner">
            <p class="logo">Newsweek</p>
            <aside><?php echo $date?></aside>
        </div>
        <nav>
            <ul class="nav_links">
                <li><a href="index.php">Home</a></li>
                <li><a href="sport.php">Sport</a></li>
                <li><a href="glazba.php">Glazba</a></li>
                <li><a href="unos.html">Unos clanka</a></li>
                <li><a href="administracija.php">Administracija</a></li>
              </ul>
        </nav>
    </header>
<body>


  <section class="forma2">
    <h1>Register</h1>
    <form action="" method="POST" id="form" enctype="multipart/form-data">
        
        <label for="ime">Ime:</label><br>
        <input type="text" name="ime" id="ime">
        <span id="porukaIme" class="error"></span><br>

        <label for="prezime">Prezime:</label><br>
        <input type="text" name="prezime" id="prezime">
        <span id="porukaPrezime" class="error"></span><br>
    
        <label for="user">Username:</label><br>
        <input type="text" name="user" id="user">
        <span id="porukaUser" class="error"></span><br>

        <label for="pass">Password:</label><br>
        <input type="password" name="pass" id="pass">
        <span id="porukaPass" class="error"></span><br>

        <button type="submit" name="login">Register</button>
    </form>


<script>
              function validateForm(event) {
              var slanje = true;
  
              var poljeIme = document.getElementById("ime");
              var ime = poljeIme.value;
              var porukaIme = document.getElementById("porukaIme");
              if (ime.length == 0) {
                  porukaIme.innerText = "Unesite ispravno ime!";
                  slanje = false;
                  poljeIme.style.border= "1px solid red";
              } else {
                  porukaIme.innerText = "";
                  poljeIme.style.border= "1px solid green";
              }

              var poljePrezime = document.getElementById("prezime");
              var prezime = poljePrezime.value;
              var porukaPrezime = document.getElementById("porukaPrezime");
              if (prezime.length == 0) {
                  porukaPrezime.innerText = "Unesite username!";
                  slanje = false;
                  poljePrezime.style.border= "1px solid red";
              } else {
                  porukaPrezime.innerText = "";
                  poljePrezime.style.border= "1px solid green";
              }

              var poljeUser = document.getElementById("user");
              var user = poljeUser.value;
              var porukaUser = document.getElementById("porukaUser");
              if (user.length == 0) {
                  porukaUser.innerText = "Unesite username!";
                  slanje = false;
                  poljeUser.style.border= "1px solid red";
              } else {
                  porukaUser.innerText = "";
                  poljeUser.style.border= "1px solid green";
              }
  
             
              var poljePass = document.getElementById("pass");
              var pass = poljePass.value;
              var porukaPass = document.getElementById("porukaPass");
              if (pass.length == 0 ) {
                  porukaPass.innerText = "Unesite password";
                  slanje = false;
                  poljePass.style.border= "1px solid red";
              } else {
                  porukaPass.innerText = "";
                  poljePass.style.border= "1px solid green";
              }
             
              if (!slanje) {
                  event.preventDefault();
              } 
          }
  
          window.onload = function() {
              document.getElementById("form").addEventListener("submit", validateForm);
          }
</script>

    <?php
        if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['ime']) && isset($_POST['prezime'])) {
            $username = $_POST['user'];
            $pass=$_POST['pass'];
            $ime=$_POST['ime'];
            $prezime = $_POST['prezime'];
            $hashpass= password_hash($pass, CRYPT_BLOWFISH);
            $razina = 0;

            $query2="SELECT korisnicko_ime FROM korisnici WHERE korisnicko_ime=?";
            $stmt2 = mysqli_stmt_init($dbc);
            if(mysqli_stmt_prepare($stmt2, $query2)){
                mysqli_stmt_bind_param($stmt2, 's', $username);
                mysqli_stmt_execute($stmt2);
                mysqli_stmt_store_result($stmt2);
                mysqli_stmt_bind_result($stmt2,$user);
                mysqli_stmt_fetch($stmt2);
            }
        if(mysqli_stmt_num_rows($stmt2) == 0){
            $query = "INSERT INTO `korisnici` (korisnicko_ime, lozinka, razina, ime, prezime) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($dbc);

            if (mysqli_stmt_prepare($stmt, $query)){

                mysqli_stmt_bind_param($stmt,"ssiss", $username, $hashpass, $razina, $ime, $prezime);
                mysqli_stmt_execute($stmt);

                echo "Registracija računa je uspješna!";
                $stmt->close();
                $stmt2->close();
                mysqli_close($dbc);
        }
    }else{
        echo"Korisnicko ime je zauzeto ili nevažeće!";
    }
}
?>  




</section>
<footer>
        <p>© NEWSWEEK 2024.</p>
    </footer>
</body>


</html>