<?php 
include 'connect.php';
define('UPLPATH', 'img/');


if(isset($_POST['update'])){
$slika = $_FILES['slika']['name'];
$naslov=$_POST['naslov'];
$ks=$_POST['ks'];
$sadrzaj=$_POST['sadrzaj'];
$kategorija=$_POST['kategorija'];

if(isset($_POST['arhiva'])){
 $arhiva=1;
}else{
 $arhiva=0;
}

$target_dir = 'img/'.$slika;
$dir = $_FILES["slika"]["tmp_name"];
move_uploaded_file($dir, $target_dir);
$id=$_POST['id'];
$query = "UPDATE clanci SET naslov='$naslov', kratki_sadrzaj='$ks', sadrzaj='$sadrzaj', kategorija='$kategorija', arhiva='$arhiva' WHERE id=$id ";

$result = mysqli_query($dbc, $query);

if($slika != '')
{
    $query2 = "UPDATE clanci SET slika='$slika' WHERE id=$id";
    $result2 = mysqli_query($dbc, $query2);
}

}
?>