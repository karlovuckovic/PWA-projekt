<?php
include 'connect.php';

$naslov=$_POST['naslov'];
$ks=$_POST['ks'];
$sadrzaj=$_POST['sadrzaj'];
$slika  = $_FILES['slika']['name'];
$kategorija=$_POST['kategorija'];
$date=date('Y-m-d');
$arhiva=isset($_POST['arhiva']) ? 1 : 0;

if(isset($_POST['arhiva'])){
    $archive=1;
}else{
    $archive=0;
}
$target_dir='img/'.$slika;

move_uploaded_file($slika= $_FILES['slika']['name'],$target_dir);
$query= "INSERT INTO clanci(naslov, kratki_sadrzaj, sadrzaj, slika, kategorija, arhiva, datum)
VALUES ('$naslov', '$ks','$sadrzaj','$slika','$kategorija','$arhiva','$date')";

$result = mysqli_query($dbc, $query) or die('Error querying databese.');
mysqli_close($dbc);
?>