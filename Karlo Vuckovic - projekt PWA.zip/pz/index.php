<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Karlo Vuckovic">
    <link rel="stylesheet" href="css/style.css">
    <title>Newsweek</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">
</head>
<body>
<main>
<header>
<?php 
$date =date("D, M d, Y");
?>
        <div class="banner">
            <p class="logo">Newsweek</p>
            <aside><?php echo $date?></aside>
        </div>
        <nav>
            <ul class="nav_links">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="sport.php">Sport</a></li>
                <li><a href="glazba.php">Glazba</a></li>
                <li><a href="unos.html">Unos clanka</a></li>
                <li><a href="administracija.php">Administracija</a></li>
              </ul>
        </nav>
    </header>
    <?php
    include 'connect.php';
    define('upath','img/');
    ?>
        <section class="prvisection">
        
        <?php
        $query="SELECT * FROM clanci WHERE arhiva=0 AND kategorija='SPORT' LIMIT 3";
        $result=mysqli_query($dbc,$query);
        echo'<h1>Sport</h1>';
        echo'<span class="crta"></span>';
        echo'<div class="container">';
            $br=0;
            while($row=mysqli_fetch_array($result)){
            echo'<article class="naslovna">';
            echo'<div class="slikanaslovna">';
            echo'<img src="'.upath.$row['slika'].'" alt="" class="slika">';
            echo'</div>';
            echo'<div class="tekstnaslovna">';
            echo'<h2>';
            echo'<a href="clanak.php?id='.$row['id'].'">';
            echo $row['naslov'];
            echo "</h2> </a>";
            echo'<p>'.$row['kratki_sadrzaj'].'</p>';
            echo'</div>';
            echo'</article>';
            }?>
    </section>
<hr>
    <section class="drugisection">
    <?php
        $query="SELECT * FROM clanci WHERE arhiva=0 AND kategorija='GLAZBA' LIMIT 3";
        $result=mysqli_query($dbc,$query);
        echo'<h1>Glazba</h1>';
        echo'<span class="crta"></span>';
        echo'<div class="container">';
            $br=0;
            while($row=mysqli_fetch_array($result)){
            echo'<article class="naslovna">';
            echo'<div class="slikanaslovna">';
            echo'<img src="'.upath.$row['slika'].'" alt="" class="slika">';
            echo'</div>';
            echo'<div class="tekstnaslovna">';
            echo'<h2>';
            echo'<a href="clanak.php?id='.$row['id'].'">';
            echo $row['naslov'];
            echo "</h2> </a>";
            echo'<p>'.$row['kratki_sadrzaj'].'</p>';
            echo'</div>';
            echo'</article>';
            }?>
    </section>

    <footer>
        <p>© NEWSWEEK 2024.</p>
    </footer>
    </main>
</body>
</html>