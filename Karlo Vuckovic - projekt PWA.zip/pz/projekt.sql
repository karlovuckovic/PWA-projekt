-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2024 at 01:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `clanci`
--

CREATE TABLE `clanci` (
  `id` int(11) NOT NULL,
  `naslov` varchar(50) NOT NULL,
  `kratki_sadrzaj` varchar(100) NOT NULL,
  `sadrzaj` varchar(10000) NOT NULL,
  `slika` varchar(50) NOT NULL,
  `kategorija` varchar(25) NOT NULL,
  `arhiva` tinyint(1) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `clanci`
--

INSERT INTO `clanci` (`id`, `naslov`, `kratki_sadrzaj`, `sadrzaj`, `slika`, `kategorija`, `arhiva`, `datum`) VALUES
(6, 'Špansko dobilo prvi betonski skate park u Zagrebu', 'Zagreb dobio prvi betonski skatepark!', 'Izgrađen je novi skate parku u zagrebačkom naselju Špansko koje spada u Gradsku četvrt Stenjevec. Radi se o prvom betonskom skate parku na području Zagreba. Ovo novozagrebačko naselje svoj je prvi skate park dobilo oko 2000. godine, a izgradila ga je skejterska zajednica. Prije četiri godine ustanovljeno je da ga treba obnoviti jer se počeo urušavati.\r\n\r\nNakon rastavljanja starog skate parka, prethodna zagrebačka vlast krenula je graditi novi park, ali se skejterskoj zajednici on nije svidio. Zatim je 2021. godine taj projekt stopiran, a današnja zagrebačka vlast napravila je novi skate park, jedinstven u Zagrebu. Sadrži i spust koji je jedinstven u široj regiji. U njemu će instruktori i skejteri učiti nove generacije skejtanju, a pogodan je i za međunarodna natjecanja.\r\n\r\nPotpredsjednica Mjesnog odbora Špansko-jug Jelena Andrić rekla je da se ovdje skejta već više od 20 godina te da je ovaj skejt park dio identiteta ovog kvarta i okupljalište mladih.\r\n\r\n– Gradska četvrt Stenjevec jedna je od 17 gradskih četvrti grada Zagreba. Uloga mjesne samouprave je da osluškuje potrebe građana i na temelju toga brine i uređuje javne površine s ciljem da život u naselju bude kvalitetniji. Ovaj skate park dio je te priče, izjavio je predsjednik Gradske četvrti Stenjevec Ivan Zelenić.\r\n\r\nPogledajte ovdje kako je ekipa skejterskih entuzijasta inicirala izgradnju skate parka u Jastrebarskom, a sve je započelo jednim pismom.', 'skpspansko.jpg', 'Sport', 0, '2024-06-06'),
(7, 'Završilo 25. izdanje Pannonian Challengea', 'Još jedan uspješan Pannonian Challenge je iza nas!', '\r\n\r\nJoš jedan uspješan Pannonian Challenge je iza nas, a ovogodišnje izdanje može se pohvaliti s velikim brojem prijavljenih natjecatelja, posebice u BMX kategoriji koja je ponovno pokazala raskoš ekstremnog sporta.\r\n\r\n“Drago nam je što smo još jednom pokazali kako je Osijek pravo mjesto za ovakva sportska natjecanja. Pannonian je ove godine proslavio svoj 25. rođendan, iza nas je niz uspješnih natjecanja, velik broj natjecatelja i publike koja svake godine pokaže koliko je važna podrška s tribina. Hvala što ste bili s nama ove godine, ali i hvala svima onima koji već 25 godina zajedno s nama razvijaju Pannonian Challenge.” – izjavio je Jurica Barać, direktor festivala.\r\n\r\nKroz skate park se ove godine provozalo čak 122 natjecatelja iz sve tri kategorije. Više od 40 njih natjecalo se u BMX kategoriji koje je obilježilo dva dana natjecanja. Ukupni nagradni fond natjecanja iznosio je 7000 eura.\r\n\r\nPetak na Pannonianu bio je rezerviran za natjecanje u skate i BMX kategoriji, a na postolja u skate kategoriji stali su; Martin Atanasov iz Bugarske kao pobjednik te Mađari Marcell Dessewffy kao drugi i Zsolt Karkossiak kao treći.\r\n\r\n“Jako sam sretan zbog Pannoniana i jako sam sretan što sam ponovno u Osijeku. Hrvatska je sjajna. Bio sam ovdje prije 2 godine, svidjelo mi se tada, a sada mi se sviđa još više. Veselim se sljedećoj godini.” – izjavio je Martin Atanasov nakon ceremonije dodjele nagrada.\r\n\r\nSubota je bila rezervirana za natjecanje u inline i bmx kategoriji, a publika je mogla uživati u trikovima natjecatelja iz više od 20 zemalja. Prvo mjesto u INLINE kategoriji odnio je CJ Wellsmore iz Australije, dok je na drugo postolje stao Jan Gašparić iz Slovenije. Broncu u INLINE kategoriji osvojio je Tin Hadžiomerspahić iz Zagreba.\r\n\r\n“Jako sam sretan što sam ponovno natrag u Hrvatskoj u Osijeku. Na ovom natjecanju su svi jako ljubazni i puni dobrodošlice. Jako sam sretan što sam na prvome mjestu jer sam nedavno imao ozljedu i nisam bio aktivan 9 mjeseci, no sada se napokon mogu natjecati.” – izjavio je CJ Wellsmore nakon natjecanja.\r\n\r\nPannonian je zatvorilo natjecanje u BMX kategoriji koje je bilo i kvalifikacijsko natjecanje za Olimpijske igre u Parizu. Pobjednom u ovoj kategoriji put prema Parizu olakšao si je Istvan Caillet iz Francuske, dok je na drugo postolje stao Zoltán Újváry. Treće mjesto na subotnjem natjecanju osvojio je Maxime Chalifour iz Kanade.\r\n\r\n“Ovo mi je treći put ovdje. Prvi put sam bio za svjetsko prvenstvo, a drugi i treći put na Pannonian Challengeu. Zadovoljstvo mi je doći u Osijek jer se ovdje osjećam super. Zadnji put sam osvojio drugo mjesto, a ovogodišnja pobjeda mi znači jako puno. Da, naravno da ću se vratiti u Osijek.”\r\n\r\nSjajnu vožnju odradile su i natjecateljice u BMX kategoriji, a pobjedu je odnijela Valeriia Liubimova iz Francuske. Drugo mjesto osvojila je Noémi Molnár iz Mađarske dok je treće mjesto pripalo Luciji Čajkovoj iz Slovačke.\r\n\r\nSkate parkom su se provozali i natjecatelji amateri dok je publika s ponosom bodrila i najmlađe natjecatelje u BMX kategoriji u kojoj je pobjedu odnio Leon Chernovets iz Varaždina.\r\n\r\nPannonian je i ove godine imao u fokusu urbanu kulturu i glazbeni program, pa je u subotu održan i graffiti jam uz bogat popratni program sponzora i partnera, a glazbeni partneri preuzeli su podij tijekom večernjeg programa. Tako su od petka do subote za DJ pultom bili UMBO, Omer, DJ GIK, INSOLATE, Sly, Flegma, Pips i Sheepatz.\r\n\r\nOrganizacijskom timu ne preostaje ništa drugo nego vas pozvati na iduće izdanje Pannonian Challengea, ali prije toga se idemo svi dobro odmoriti.\r\n\r\nVidimo se ponovno u Osijeku u skate parku.\r\n', 'pannonian.jpg', 'Sport', 0, '2024-06-06'),
(8, 'Scooter Best Trick zatvorio natjecanje u kategorij', 'Scooter Pro Finals uvijek je sjajna predstava!', 'I u tom pogledu, superzvijezda discipline Jamie Hull nije nadmašen. Britanac se doslovce bacio u dupli backflip s petostrukim tailwhipom (da, pet!) kako bi osvojio 3. mjesto. Drugo mjesto pripalo je Roometu Sååliku iz Estonije, koji je bio prvi na svijetu s trikom ice-pick to frontflip, koji nikad prije nije viđen na ovakvom mjestu.\r\n\r\n \r\n\r\nA najbolji od najboljih ide Jacku Wardu, vozač iz parka \"Adrenaline alley\" u Corbyju. Luda, riskantan trik, stvar koju nikada ne biste vidjeli u normalnom run-u, inovativna i opasna. Jednostavno, najbolji trik danas: frontflip nothing front scooter flip na step-up prijenosu - još uvijek je dovoljno da se naježimo samo kada to pišemo!\r\n\r\n \r\n\r\nA ovo su očito izvedbe za kojima je FISE publika gladna, jer su vrištali i vikali kako bi gurnuli naše vozače do krajnjih granica. Izvedba koju već jedva čekamo ponovno vidjeti na obalama Leza. Hvala ti, Montpellier, bilo je jednostavno ludo, i jedva čekamo da te vidimo i sljedeće godine!', 'fise.jpg', 'Sport', 0, '2024-06-06'),
(9, 'Drito X - počelo deseto izdanje Drita!', 'Jubilarno 10. izdanje Drito festivala.', 'Najteži zadatak ove godine su dobili Jyro i Camel, mladi puležanski dvojac koji je nakon Lil Drita krajem prošle godine dobio priliku da sada nastupa i pred još većom publikom. Dvojac je otvorio festival poprilično zainteresirano i energično i dečki su pokazali da se znaju snalaziti na pozornici, a veliki pritisak koji je sigurno bio prisutan, na njihovim licima i izvedbi nije bio vidljiv. <br>\r\n\r\nSBL je pojavom na pozornici podigao atmosferu i energiju na sljedeću razinu. Ovaj mladi trap kolektiv iz Kutine nastavlja impresionirati svojim izvedbama iz nastupa u nastup, kemija među njima je odlična, a od publike, koja još nije bila u potpunosti formirana, je prihvaćena srčano. <br>\r\n\r\nDošao je red i na Sjenu, za kojeg je veća količina fanova bila razočarana što nije dobio dulje vrijeme na pozornici, no to nije spriječilo Sjenu da maksimalno iskoristi priliku te pokaže najbolje od sebe. Tijekom nastupa su mu se pridružili i bejbe, Kuku$ i Buntai te su se tada na trenutke počele osjetiti prve naznake one jako dobro poznate atmosfere Drito festivala. <br>', 'dritox.jpeg', 'Glazba', 0, '2024-06-06'),
(10, 'Hiljson Mandela došao na vrh Billboarda', 'Baby Lasagnu s trona je srušio zagrebački reper...', 'Izvođač Baby Lasagna bio je ovogodišnji predstavnik Hrvatske na Euroviziji te je osvojio visoko drugo mjesto s najviše bodova od glasova publike, pa mu je pobjeda zapravo promaknula za dlaku. Njegov hit \"Rim Tim Tagi Dim\" harao je glazbenim ljestvicama i dugo je bio prvi na hrvatskoj Billboard ljestvici. Sada ga je reper Hiljson Mandela srušio s trona te se i sam pohvalio da je na prvom mjestu s pjesmom \"Ankaran\" koju izvodi s srpskim reperom Bibom iz grupe Crni Cerak. \r\n\r\n- Službeno: Hiljson Mandela broj 1 na hrvatskom Billboardu. Nakon što smo postali broj 1 na YouTube trendingu u Sloveniji, Srbiji i Hrvatskoj i popeli se na broj 3 u Crnoj Gori, 4 u Makedoniji i 7 u Bosni i Hercegovini, sada smo na vrhu Billboard ljestvice za Hrvatsku. Svi koji ste sumnjali, ma hvala Vam! - poručio je radosno Hiljson Mandela uz fotografiju na kojoj se pokazuju prva tri mjesta domaćeg Billboarda.', 'hiljs.webp', 'Glazba', 0, '2024-06-06'),
(11, 'Grše zauzeo prva dva mjesta Billboardove ljestvice', 'Grše opet na vrhu ljestvice!', 's pjesmom Fantazija, koju pjeva s pjevačicom Mijom Čičak. Visoko se pozicionirao i njegov duet Tokyo Drift sa srpskom pjevačicom Mimi Mercedez. Pjesma je objavljena prije manje od dva tjedna, a na YouTubeu dosad ima 1.5 milijuna pregleda i zauzela je vrh trendinga.\r\n\r\n\"Još jedan rekord, imamo broj jedan i broj dva na Billboardu te ukupno pet pjesama u top 25. Hvala svima\", pohvalio se Grše na Instagramu.\r\n\r\nReperov hit Mamma Mia trenutno je na 10. mjestu na ljestvici, a 18. mjesto zauzela je njegova pjesma Sip. Na 21. mjestu trenutno je i pjesma Led, koju također pjeva s Mijom Čičak, poznatijom kao Miach. \r\n\r\nGrše je tako ponovno prešišao regionalne pjevače koji su redovito na vrhu slušanosti u Hrvatskoj. Treće, četvrto i peto mjesto redom su zauzeli Amna i Biba, pa Darko Lazić i Zera te Coby i Rouzi. Šesto i deveto mjesto zauzeo je Desingerica.\r\n\r\nPodsjećamo, reper se prvi put našao na vrhu Billboarda s pjesmom Mamma Mia u travnju prošle godine. Tada je postao prvi hrvatski glazbenik na vrhu ove liste najslušanijih pjesama na digitalnim streaming-servisima u Hrvatskoj. Nedavno je osvojio nagradu Cesarica Digital Bestseller za najuspješnijeg hrvatskog izvođača na streaming-servisima 2023. godine. \r\n\r\nPrije manje od dva tjedna u zagrebačkom Domu sportova održao je svoj najveći samostalni koncert u karijeri. U više od dva sata nastupa i uz niz gostiju koji su mu se pridružili na pozornici potvrdio je status jednog od najistaknutijih aktera trenutne domaće hip-hop scene.', 'grse.jpg', 'Glazba', 0, '2024-06-06'),
(20, 'Bjelovar domaćin natjecanja', 'Bjelovar će 8. i 9. lipnja ponovo biti domaćin ekstremnim sportašima', 'Natjecanje se odvija u više disciplina: BMX biciklizmu, skateboardingu, inline rolama te scooteringu (romobili).\r\nOsim disciplina, na natjecanju imamo i kategorije: juinior i senior. Iznimno nam je drago organizirati junior natjecanja i na taj način dati mladim nadama vjetar u leđa, a nekim njihovim vršnjacima odškrinuti vrata ekstremnih sportova.\r\n\r\nU senior kategoriji natjecat će se BMX vozači, skateboarderi i inline roleri iz cijele Hrvatske i šire. Već sada nam se najavilo tridesetak natjecatelja iz Osijeka, Zagreba, Pule, Rijeke, Vinkovaca, Varaždina, Ljubljane i Maribora. Neki od natjecatelja okitili su se državnim, europskim i svjetskim titulama.\r\nPosjetitelji i natjecatelji moći će uživati u izložbi fotografija ekstremnog sporta, jedan od izlagača je i Marin Stupar, osječki fotograf koji osim već spomenutog Pannonian Challengea, fotografira i događaje Svjetskog kupa u BMX biciklizmu u cijelom svijetu. Naravno, tu je i gastro ponuda  te tekuća okrijepa, ističu organizatori.', 'suma.jpg', 'Sport', 1, '2024-06-09'),
(21, 'Peki izdao debitantski album!', 'Mladi reper iz Drniša, Peki, objavio je svoj debitantski album pod nazivom “Fortuna”.', 'Album se sastoji od dvanaest pjesama, a na albumu se kao gosti pojavljuju vodeća imena domaće hip-hop scene, Hiljson Mandela, Vojko V, Bore Balboa i Grše. Duet s Gršom u pjesmi “Mangio Pasta” je ovog tjedna ušao u Billboard Croatia Songs listu.\r\n\r\nOsim navedenih izvođača, gost na izdanju je još jedna domaća trap senzacija, velikogorički reper Baks, na pjesmi “Čim se pojavimo u gradu”, koja je odabrana i kao vodeći singl s albuma.\r\n\r\nPrateći videospot singla “Čim se pojavimo u gradu” redateljski potpisuju Luka Matković i Ana Cindrić.\r\n\r\nU stvaranju albuma “Fortuna” sudjelovalo je šest producenata, a to su Mihovil Šoštarić Lockroom i El Maar te Trky, Traposlavia, Fynolla i Luka Pekas.\r\n\r\nPravog imena Josip Pekas, ovaj mladi izvođač, autor i producent odrastao je u glazbenoj obitelji i stekao je formalno glazbeno obrazovanje. Svira saksofon i bubnjeve, a pisanjem i produciranjem glazbe počeo se baviti samo tjedan dana prije nego što je napravio prvu pjesmu. Iza sebe ima niz festivalskih nastupa i suradnji kao i EP izdanje “Druga strana lica” iz 2022. godine. U skorijoj budućnosti planira održati svoj prvi samostalni koncert.\r\n\r\nPekijev debitantski album “Fortuna” možete poslušati u nastavku.', 'fortuna.jpg', 'Glazba', 1, '2024-06-10');

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `korisnicko_ime` varchar(50) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` tinyint(1) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `prezime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `korisnicko_ime`, `lozinka`, `razina`, `ime`, `prezime`) VALUES
(1, 'kvucko', '$2y$10$5vS.QFAd3tNH3kKKs9NmAu9ZlkXJrtF/8Z9iu5qebm0gOHlcb8g.e', 1, 'Karlo', 'Vučković'),
(3, 'ihorvat', '$2y$10$GtqN55RWvREorRtALyRiyOFs93lroXssjAZd2pZU2E0WAfe/w6Fpq', 0, 'Ivan', 'Horvat'),
(4, 'alipovac', '$2y$10$EHPHMOT.twKbdoPGhNUDuOVmy.JEZmOUxNbGLPMdNc7TOvh5zPo0y', 0, 'Ana', 'Lipovac'),
(5, 'mpolovic', '$2y$10$F3.FxNj.DhTszsk8x.356uLk1dxcMJNqV4wJjw1vtgrlz10nt6gKm', 0, 'Matija', 'Polović'),
(10, 'mcicak', '$2y$10$B33YJIvWUVVQpQqzaGm26OWlaKVM.Gv6rE/3WRwinVsNgKepmhfmq', 0, 'Marta', 'Čičak');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clanci`
--
ALTER TABLE `clanci`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clanci`
--
ALTER TABLE `clanci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
