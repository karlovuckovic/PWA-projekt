<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Glazba</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">

</head>
<body>
<header>
<?php 
$date =date("D, M d, Y");
?>
        <div class="banner">
            <p class="logo">Newsweek</p>
            <aside><?php echo $date?></aside>
        </div>
        <nav>
            <ul class="nav_links">
                <li><a href="index.php">Home</a></li>
                <li><a href="sport.php" class="active">Sport</a></li>
                <li><a href="glazba.php">Glazba</a></li>
                <li><a href="unos.html">Unos clanka</a></li>
                <li><a href="administracija.php">Administracija</a></li>
              </ul>
        </nav>
    </header>

    <?php
    include 'connect.php';
    define('upath','img/');
    ?>
        <section class="sportsection">
        
        <?php
        $query="SELECT * FROM clanci WHERE kategorija='SPORT'";
        $result=mysqli_query($dbc,$query);
            $br=0;
            while($row=mysqli_fetch_array($result)){
            echo'<article class="sport">';

            echo'<div class="slikacon">';
            echo'<img src="'.upath.$row['slika'].'" alt="" class="slika">';
            echo'</div>';

            echo'<div class="tekst">';
           
            echo'<p>';
            echo $row['datum'];
            echo "</p>";

            echo'<h2>';
            echo'<a href="clanak.php?id='.$row['id'].'">';
            echo $row['naslov'];
            echo "</h2> </a>";
            echo'<p>'.$row['kratki_sadrzaj'].'</p>';
            echo'</article>';
            echo'</div>';
            }?>
    </section>

    <footer>
        <p>© NEWSWEEK 2024.</p>
    </footer>
</body>
</html>