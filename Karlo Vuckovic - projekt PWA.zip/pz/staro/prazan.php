<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php

include 'connect.php';
if(isset($_POST['password']) && isset($_POST['username'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

//Check input values
echo "Username: " . htmlspecialchars($username) . "<br>";
echo "Password: " . htmlspecialchars($password) . "<br>";



    $query = "SELECT korisnicko_ime,lozinka, razina FROM korisnici WHERE korisnicko_ime=?";
    $stmt = mysqli_stmt_init($dbc);

    if(mysqli_stmt_prepare($stmt, $query)){
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt,$user,$pass,$razina);
        mysqli_stmt_fetch($stmt);
        

//Check if any rows were returned
echo "Rows returned: " . mysqli_stmt_num_rows($stmt) . "<br>";
echo "Username from DB: " . htmlspecialchars($user) . "<br>";
echo "Hashed password from DB: " . htmlspecialchars($pass) . "<br>";



        if (password_verify($_POST['password'], $pass) && mysqli_stmt_num_rows($stmt)>0) {
                echo 'Uspjesan login';
                $prijava = true;
                if($razina == 1){
                    $admin= true;
                    echo'Razina korisnika je administrator';
                }else{
                    $admin=false;
                }
                $_SESSION['$username'] = $user;
                $_SESSION['razina'] = $razina;
        }else{
            echo"Login nije uspio";
            $prijava = false;
        }
    }
}



?>