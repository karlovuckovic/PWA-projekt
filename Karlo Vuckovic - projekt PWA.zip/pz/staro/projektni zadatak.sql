CREATE DATABASE `Projekt` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `Projekt`;

CREATE TABLE `clanci`(
    `id` int NOT NULL AUTO_INCREMENT,
    `naslov` varchar(50) NOT NULL,
    `kratki_sadrzaj` varchar(50) NOT NULL, 
    `sadrzaj` varchar(10000) NOT NULL,
    `slika` varchar(50) NOT NULL,
    `kategorija` varchar(25) NOT NULL,
    PRIMARY KEY(`id`)
);

ALTER TABLE `clanci` ADD COLUMN `arhiva` tinyint(1) NOT NULL;
ALTER TABLE `clanci` ADD COLUMN `datum` DATE NOT NULL;

CREATE TABLE `korisnici`(
    `id` int NOT NULL AUTO_INCREMENT,
    `korisnicko_ime` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    PRIMARY KEY(`id`)
);
INSERT INTO `korisnici` (korisnicko_ime, lozinka,razina) VALUES ('user','password', 1);
ALTER TABLE `korisnici` ADD COLUMN `razina` tinyint(1) NOT NULL;